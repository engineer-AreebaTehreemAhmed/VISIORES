import os
import zipfile
import pandas as pd
import numpy as np
from tqdm import tqdm

def load_data(zip_path, extract_path):
    """Load and extract data from zip file"""
    if not os.path.exists(extract_path):
        os.makedirs(extract_path)
    
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)
    
    return os.path.join(extract_path, 'arxiv-metadata-oai-snapshot.json')

def preprocess_data(json_path, sample_size=None):
    """Preprocess data and generate embeddings"""
    chunks = pd.read_json(json_path, lines=True, chunksize=100000)
    df_chunk = next(chunks)
    
    if sample_size:
        df_chunk = df_chunk.sample(sample_size)
    
    return df_chunk

def save_embeddings(embeddings, path):
    """Save embeddings to file"""
    np.save(path, embeddings)

def load_embeddings(path):
    """Load embeddings from file"""
    return np.load(path)